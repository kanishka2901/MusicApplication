package com.songs.service;

import com.songs.model.User;

public interface UserService {
	User register(User user);
}